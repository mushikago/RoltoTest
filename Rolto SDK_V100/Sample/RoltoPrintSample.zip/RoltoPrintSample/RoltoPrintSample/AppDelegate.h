//
//  AppDelegate.h
//  RoltoPrintSample
//
//  Copyright: (C) 2014 KING JIM CO.,LTD.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
