//
//  SelectPrinterTableViewController.h
//  RoltoPrintSample
//
//  Copyright: (C) 2014 KING JIM CO.,LTD.
//

#import <UIKit/UIKit.h>

@interface SelectPrinterTableViewController : UITableViewController

@property (nonatomic) NSArray *printers;

@end
