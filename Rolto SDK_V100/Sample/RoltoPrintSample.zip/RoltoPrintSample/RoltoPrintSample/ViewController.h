//
//  ViewController.h
//  RoltoPrintSample
//
//  Copyright: (C) 2014 KING JIM CO.,LTD.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (nonatomic, weak) IBOutlet UIImageView *imageView;
@property (nonatomic, weak) IBOutlet UILabel *selectPrinterLabel;
@property (nonatomic, weak) IBOutlet UILabel *requestStatusLabel;
@property (nonatomic, weak) IBOutlet UILabel *printLabel;
@property (nonatomic, weak) IBOutlet UIActivityIndicatorView *indicatorView;
@property (nonatomic, weak) IBOutlet UISwitch *multipleImagesSwitch;
@property (nonatomic, weak) IBOutlet UILabel *launchRoltoLabel;

@property (nonatomic) NSInteger selectedIndex;
@property (nonatomic) BOOL printing;

- (IBAction)returnSelectPrinterForSegue:(UIStoryboardSegue *)segue;

@end
